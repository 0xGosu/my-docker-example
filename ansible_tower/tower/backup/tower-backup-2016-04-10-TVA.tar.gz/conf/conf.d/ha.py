
# The system UUID, as captured by Ansible.
SYSTEM_UUID = 'a9c7c79c-0ba9-4378-ab22-585a19f0e88f'
